package service;

public enum Piece {
        GREEN,BLUE,EMPTY

}
